/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    screens: {
      'sm': '640px',
      // => @media (min-width: 640px) { ... }

      'md': '768px',
      // => @media (min-width: 768px) { ... }

      'lg': '1024px',
      // => @media (min-width: 1024px) { ... }

      'xl': '1280px',
      // => @media (min-width: 1280px) { ... }

      '2xl': '1536px',
      // => @media (min-width: 1536px) { ... }
    },
    extend: {
      fontFamily: {
        yellowtail: ['Yellowtail',  ]
      },
      backgroundImage: {
        'blog': "url('./img/Image (23).png')",
        'greens': "url('./img/Image (24).png')",
        'tomato': "url('./img/Image (25).png')",
        'carrots': "url('./img/Image (26).png')",
        'man': "url('./img/Image (27).png')",
        'girl': "url('./img/Image (28).png')",
        'garbage': "url('./img/Image (29).png')",
        'fruit': "url('./img/Photo (2).png')",
        'contact': "url('./img/Background.jpg')",
        'leaf': "url('./img/Image (31).png')",
      },
    },
  },
  plugins: [],
}
